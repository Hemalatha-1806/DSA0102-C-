#include <iostream>
#include <iomanip>

struct Transaction { char type; double amount; double balanceAfter; };

class SavingsAccount {
    static const int MAX = 10;
    long        accNo;
    double      balance;
    Transaction history[MAX];
    int         start;        // index of the oldest transaction
    int         count;

    void record(char type, double amount)
    {
        Transaction t{type, amount, balance};
        if (count < MAX) {
            history[(start + count) % MAX] = t;   // O(1)
            ++count;
        } else {
            history[start] = t;                   // overwrite the oldest, O(1)
            start = (start + 1) % MAX;
        }
    }
public:
    SavingsAccount(long no, double opening) : accNo(no), balance(opening), start(0), count(0) {}
    double getBalance() const { return balance; }
    void deposit(double a) { if (a <= 0) return; balance += a; record('D', a); }
    bool withdraw(double a) { if (a <= 0 || a > balance) return false; balance -= a; record('W', a); return true; }
    void miniStatement() const
    {
        std::cout << "Mini statement for A/c " << accNo << '\n';
        std::cout << std::fixed << std::setprecision(2);
        for (int i = 0; i < count; ++i) {
            const Transaction& t = history[(start + i) % MAX];
            std::cout << std::setw(2) << i + 1 << ". "
                      << (t.type == 'D' ? "Deposit   " : "Withdrawal")
                      << std::setw(10) << t.amount
                      << "   Bal " << std::setw(10) << t.balanceAfter << '\n';
        }
    }
};

int main()
{
    SavingsAccount acc(1001234, 5000);
    for (int i = 1; i <= 7; ++i) acc.deposit(100 * i);
    acc.withdraw(250);
    acc.withdraw(100);
    acc.deposit(1000);
    acc.withdraw(75);
    acc.deposit(20);
    std::cout << "12 transactions done, only the last 10 are kept\n\n";
    acc.miniStatement();
    std::cout << "\nBalance = " << acc.getBalance() << '\n';
}
