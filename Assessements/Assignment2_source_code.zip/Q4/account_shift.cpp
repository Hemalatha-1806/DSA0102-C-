#include <iostream>
#include <iomanip>

struct Transaction {
    char   type;        // 'D' deposit, 'W' withdrawal
    double amount;
    double balanceAfter;
};

class SavingsAccount {
    static const int MAX = 10;          // change to 50 for the bank's new requirement
    long        accNo;
    double      balance;
    Transaction history[MAX];           // private: only the class may touch the order/count
    int         count;                  // number of valid entries (0..MAX)

    void record(char type, double amount);   // helper, defined outside

public:
    SavingsAccount(long no, double opening) : accNo(no), balance(opening), count(0) {}

    // defined inside the class (implicitly inline)
    double getBalance() const { return balance; }

    void deposit(double amount)
    {
        if (amount <= 0) return;
        balance += amount;
        record('D', amount);
    }

    // defined outside using the scope resolution operator
    bool withdraw(double amount);
    void miniStatement() const;
};

void SavingsAccount::record(char type, double amount)
{
    Transaction t{type, amount, balance};
    if (count == MAX) {                         // 11th transaction: drop the oldest
        for (int i = 0; i < MAX - 1; ++i)       // shift left by one  -> O(MAX)
            history[i] = history[i + 1];
        history[MAX - 1] = t;
    } else {
        history[count++] = t;
    }
}

bool SavingsAccount::withdraw(double amount)
{
    if (amount <= 0 || amount > balance) return false;
    balance -= amount;
    record('W', amount);
    return true;
}

void SavingsAccount::miniStatement() const
{
    std::cout << "Mini statement for A/c " << accNo << '\n';
    std::cout << std::fixed << std::setprecision(2);
    for (int i = 0; i < count; ++i)
        std::cout << std::setw(2) << i + 1 << ". "
                  << (history[i].type == 'D' ? "Deposit   " : "Withdrawal")
                  << std::setw(10) << history[i].amount
                  << "   Bal " << std::setw(10) << history[i].balanceAfter << '\n';
}

int main()
{
    SavingsAccount acc(1001234, 5000);
    for (int i = 1; i <= 7; ++i) acc.deposit(100 * i);       // 7 transactions
    acc.withdraw(250);
    acc.withdraw(100);
    acc.deposit(1000);
    acc.withdraw(75);                                         // 11th
    acc.deposit(20);                                          // 12th
    std::cout << "12 transactions done, only the last 10 are kept\n\n";
    acc.miniStatement();
    std::cout << "\nBalance = " << acc.getBalance() << '\n';
}
