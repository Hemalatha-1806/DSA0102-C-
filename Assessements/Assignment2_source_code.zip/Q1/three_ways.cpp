#include <iostream>
#include <string>

// 1. by value  -> works on a copy, caller's fee never changes
void concessionByValue(long long fee, int percent)
{
    fee -= fee * percent / 100;
    std::cout << "  inside byValue   : " << fee << '\n';
}

// 2. by reference -> fee is an alias of the caller's variable
void concessionByRef(long long& fee, int percent)
{
    fee -= fee * percent / 100;
    std::cout << "  inside byRef     : " << fee << '\n';
}

// 3. by pointer -> pointer holds the caller's address, we dereference it
void concessionByPtr(long long* fee, int percent)
{
    if (fee == nullptr) return;           // pointers can be null, so check
    *fee -= *fee * percent / 100;
    std::cout << "  inside byPtr     : " << *fee << '\n';
}

// Design decision: return the new fee (pure function), caller decides what to store
long long concessionReturn(long long fee, int percent)
{
    return fee - fee * percent / 100;
}

// const reference: read only, no copy of a big object
struct Student {
    std::string name;
    long long fee;
    char notes[1000];                     // makes the object large
};
void printStudent(const Student& s)
{
    std::cout << "  " << s.name << " fee = " << s.fee << '\n';
}

int main()
{
    long long fee = 45000;

    std::cout << "Start fee = " << fee << "\n\n";

    std::cout << "Call by value (10% merit):\n";
    concessionByValue(fee, 10);
    std::cout << "  stored fee after : " << fee << "\n\n";

    std::cout << "Call by reference (10% merit):\n";
    concessionByRef(fee, 10);
    std::cout << "  stored fee after : " << fee << "\n\n";

    fee = 45000;
    std::cout << "Call by pointer (10% merit):\n";
    concessionByPtr(&fee, 10);
    std::cout << "  stored fee after : " << fee << "\n\n";

    // several concessions on one student: merit 10 + sports 15 + single parent 25
    fee = 45000;
    long long f = concessionReturn(concessionReturn(concessionReturn(fee, 10), 15), 25);
    std::cout << "Chained return version: 45000 -> " << f << '\n';

    Student s{"Asha", 45000, {}};
    std::cout << "\nconst reference print:\n";
    printStudent(s);
    std::cout << "sizeof(long long) = " << sizeof(long long)
              << ", sizeof(Student) = " << sizeof(Student) << '\n';
}
