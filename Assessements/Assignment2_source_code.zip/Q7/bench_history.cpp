#include <iostream>
#include <chrono>
#include <algorithm>
#include <deque>

struct Transaction { char type; double amount; double balanceAfter; };

// ORIGINAL design: shift the array left when full  -> O(MAX) per record
template <int MAX>
class ShiftHistory {
    Transaction h[MAX];
    int count = 0;
public:
    void add(const Transaction& t)
    {
        if (count == MAX) {
            for (int i = 0; i < MAX - 1; ++i) h[i] = h[i + 1];
            h[MAX - 1] = t;
        } else h[count++] = t;
    }
    double checksum() const { double s = 0; for (int i = 0; i < count; ++i) s += h[i].amount * (i + 1); return s; }
};

// REDESIGN: circular buffer with a start index -> O(1) per record
template <int MAX>
class CircularHistory {
    Transaction h[MAX];
    int start = 0, count = 0;
public:
    void add(const Transaction& t)
    {
        if (count < MAX) { h[(start + count) % MAX] = t; ++count; }
        else { h[start] = t; start = (start + 1 == MAX) ? 0 : start + 1; }
    }
    double checksum() const { double s = 0; for (int i = 0; i < count; ++i) s += h[(start + i) % MAX].amount * (i + 1); return s; }
};

// ALTERNATIVE: std::deque (push_back + pop_front)
template <int MAX>
class DequeHistory {
    std::deque<Transaction> h;
public:
    void add(const Transaction& t) { h.push_back(t); if ((int)h.size() > MAX) h.pop_front(); }
    double checksum() const { double s = 0; int i = 0; for (auto& t : h) s += t.amount * (++i); return s; }
};

template <class H>
void run(const char* name, int ops, double& ms, double& chk)
{
    double best = 1e18;
    for (int rep = 0; rep < 5; ++rep) {
        H history;
        auto t0 = std::chrono::steady_clock::now();
        for (int i = 0; i < ops; ++i) history.add({(i & 1) ? 'W' : 'D', double(i % 1000), double(i)});
        auto t1 = std::chrono::steady_clock::now();
        best = std::min(best, std::chrono::duration<double, std::milli>(t1 - t0).count());
        chk = history.checksum();
    }
    ms = best;
    (void)name;
}

template <int MAX>
void compare(int ops)
{
    double ts, tc, td, cs, cc, cd;
    run<ShiftHistory<MAX>>("shift", ops, ts, cs);
    run<CircularHistory<MAX>>("circ", ops, tc, cc);
    run<DequeHistory<MAX>>("deque", ops, td, cd);
    std::cout << "capacity " << MAX << " | shift " << ts << " ms | circular " << tc
              << " ms | deque " << td << " ms | speed-up shift/circular = " << ts / tc
              << " | same result: " << (cs == cc && cc == cd) << '\n';
}

int main()
{
    const int ops = 1000000;
    std::cout << ops << " transactions per run, best of 5\n";
    compare<10>(ops);
    compare<50>(ops);
    compare<500>(ops);
    compare<5000>(ops);
    std::cout << "sizeof(Transaction) = " << sizeof(Transaction) << " bytes\n";
}
