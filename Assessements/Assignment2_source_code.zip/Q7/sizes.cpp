#include <iostream>
struct Transaction { char type; double amount; double balanceAfter; };
struct Shift10 { long accNo; double balance; Transaction h[10]; int count; };
struct Circ10  { long accNo; double balance; Transaction h[10]; int start; int count; };
struct Shift50 { long accNo; double balance; Transaction h[50]; int count; };
struct Circ50  { long accNo; double balance; Transaction h[50]; int start; int count; };
int main(){ std::cout << sizeof(Shift10) << ' ' << sizeof(Circ10) << ' ' << sizeof(Shift50) << ' ' << sizeof(Circ50) << '\n'; }
