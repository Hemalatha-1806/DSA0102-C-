#include <iostream>
#include <string>

class TicketOffice {            // one office object per bus
    int issued = 0;
    int capacity;
public:
    explicit TicketOffice(int cap) : capacity(cap) {}
    int nextSeat() { return issued < capacity ? ++issued : 0; }   // 0 = waiting
    int count() const { return issued; }
};

class BusTicket {
    int seat;
    std::string name;
public:
    BusTicket(const std::string& n, TicketOffice& office) : seat(office.nextSeat()), name(n) {}
    void print() const
    {
        std::cout << name << ": " << (seat ? "Seat " + std::to_string(seat) : std::string("Waiting")) << '\n';
    }
};

int main()
{
    TicketOffice bus1(3), bus2(2);          // two buses at the same time
    BusTicket a("Asha", bus1), b("Bala", bus1), c("Chitra", bus2), d("Dev", bus2), e("Eswar", bus2);
    a.print(); b.print(); c.print(); d.print(); e.print();
    std::cout << "bus1 issued " << bus1.count() << ", bus2 issued " << bus2.count() << '\n';
}
