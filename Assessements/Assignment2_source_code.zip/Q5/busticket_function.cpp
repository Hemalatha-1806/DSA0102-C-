#include <iostream>
#include <string>

class BusTicket {
    static int issued;
    static const int CAPACITY = 3;
    int seat;
    std::string name;
public:
    explicit BusTicket(const std::string& n) : seat(0), name(n)
    {
        if (issued < CAPACITY) { ++issued; seat = issued; }
    }
    static int count() { return issued; }
    void print() const
    {
        std::cout << "  " << name << ": "
                  << (seat ? "Seat " + std::to_string(seat) : std::string("Waiting")) << '\n';
    }
    // a static member function has no 'this', so this would NOT compile:
    // static int getSeat() { return seat; }   // error: invalid use of member 'seat' in static member function
};
int BusTicket::issued = 0;

void bookTwo(const std::string& a, const std::string& b)
{
    BusTicket t1(a), t2(b);              // destroyed when the function ends
    t1.print();
    t2.print();
}

int main()
{
    std::cout << "Call 1:\n";
    bookTwo("Asha", "Bala");
    std::cout << "  issued after call 1 = " << BusTicket::count() << '\n';
    std::cout << "Call 2:\n";
    bookTwo("Chitra", "Dev");
    std::cout << "  issued after call 2 = " << BusTicket::count() << '\n';
    std::cout << "Call 3:\n";
    bookTwo("Eswar", "Fathima");
    std::cout << "  issued after call 3 = " << BusTicket::count() << '\n';
}
