#include <iostream>
#include <chrono>
#include <algorithm>
#include <vector>

class Time {
    int h, m;
public:
    Time(int hh, int mm) : h(hh), m(mm) {}
    friend int  minutesBetweenNoInline(const Time& a, const Time& b);
    friend int  minutesBetweenInline(const Time& a, const Time& b);
    int minutesTo(const Time& o) const
    {
        int ta = h * 60 + m, tb = o.h * 60 + o.m;
        return ta > tb ? ta - tb : tb - ta;
    }
    int getH() const { return h; }
    int getM() const { return m; }
};

__attribute__((noinline)) int minutesBetweenNoInline(const Time& a, const Time& b)
{
    int ta = a.h * 60 + a.m, tb = b.h * 60 + b.m;
    return ta > tb ? ta - tb : tb - ta;
}
inline int minutesBetweenInline(const Time& a, const Time& b)
{
    int ta = a.h * 60 + a.m, tb = b.h * 60 + b.m;
    return ta > tb ? ta - tb : tb - ta;
}
inline int minutesGetters(const Time& a, const Time& b)
{
    int ta = a.getH() * 60 + a.getM(), tb = b.getH() * 60 + b.getM();
    return ta > tb ? ta - tb : tb - ta;
}

const int N = 10000000;

template <class F>
double timeIt(const std::vector<Time>& v, F f, long long& result)
{
    double best = 1e9;
    for (int rep = 0; rep < 7; ++rep) {
        auto t0 = std::chrono::steady_clock::now();
        long long sum = 0;
        const int M = (int)v.size();
        for (int i = 0; i < N; ++i)
            sum += f(v[i & (M - 1)], v[(i * 7 + 3) & (M - 1)]);   // M is a power of two
        auto t1 = std::chrono::steady_clock::now();
        result = sum;
        best = std::min(best, std::chrono::duration<double, std::milli>(t1 - t0).count());
    }
    return best;
}

int main()
{
    std::vector<Time> v;
    for (int i = 0; i < 1024; ++i) v.emplace_back((i * 5) % 24, (i * 11) % 60);
    long long r1, r2, r3, r4;
    double t1 = timeIt(v, [](const Time& a, const Time& b) { return minutesBetweenNoInline(a, b); }, r1);
    double t2 = timeIt(v, [](const Time& a, const Time& b) { return minutesBetweenInline(a, b); }, r2);
    double t3 = timeIt(v, [](const Time& a, const Time& b) { return a.minutesTo(b); }, r3);
    double t4 = timeIt(v, [](const Time& a, const Time& b) { return minutesGetters(a, b); }, r4);
    std::cout << "checksums equal: " << (r1 == r2 && r2 == r3 && r3 == r4) << " (" << r1 << ")\n";
    std::cout << "friend, noinline : " << t1 << " ms\n";
    std::cout << "friend, inline   : " << t2 << " ms\n";
    std::cout << "member function  : " << t3 << " ms\n";
    std::cout << "public getters   : " << t4 << " ms\n";
}
