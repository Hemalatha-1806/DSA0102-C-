#include <iostream>

class Time {
    int h, m;
public:
    Time(int hh, int mm) : h(hh), m(mm) {}
    friend int minutesBetween(const Time& a, const Time& b);
    friend bool earlier(const Time& a, const Time& b);
};
inline int minutesBetween(const Time& a, const Time& b)
{
    int ta = a.h * 60 + a.m, tb = b.h * 60 + b.m;
    return ta > tb ? ta - tb : tb - ta;
}
inline bool earlier(const Time& a, const Time& b) { return a.h * 60 + a.m < b.h * 60 + b.m; }

void test(const char* label, Time x, Time y, int expMin, bool expEarlier)
{
    int  got  = minutesBetween(x, y);
    bool gotE = earlier(x, y);
    std::cout << label << " -> minutes = " << got << " (expected " << expMin << "), earlier = "
              << std::boolalpha << gotE << " (expected " << expEarlier << ")  "
              << ((got == expMin && gotE == expEarlier) ? "PASS" : "FAIL") << '\n';
}

int main()
{
    test("09:45 vs 13:10 (given)       ", Time(9, 45),  Time(13, 10), 205, true);
    test("13:10 vs 09:45 (reversed)    ", Time(13, 10), Time(9, 45),  205, false);
    test("11:50 vs 12:20 (across noon) ", Time(11, 50), Time(12, 20), 30,  true);
    test("12:20 vs 11:50 (across noon) ", Time(12, 20), Time(11, 50), 30,  false);
    test("10:30 vs 10:30 (same time)   ", Time(10, 30), Time(10, 30), 0,   false);
    test("00:00 vs 23:59 (day ends)    ", Time(0, 0),   Time(23, 59), 1439,true);
}
