#include <iostream>
#include <vector>

// returns a reference to the highest mark -> can be modified directly
int& highest(int marks[], int n)
{
    int pos = 0;
    for (int i = 1; i < n; ++i)
        if (marks[i] > marks[pos]) pos = i;
    return marks[pos];
}

// const reference: caller can read but not change
const int& highestRead(const int marks[], int n)
{
    int pos = 0;
    for (int i = 1; i < n; ++i)
        if (marks[i] > marks[pos]) pos = i;
    return marks[pos];
}

// copy: caller gets an independent value
int highestCopy(const int marks[], int n)
{
    int pos = 0;
    for (int i = 1; i < n; ++i)
        if (marks[i] > marks[pos]) pos = i;
    return marks[pos];
}

// WRONG: returns reference to a local variable (dangling reference)
int& badHighest(int marks[], int n)
{
    int best = marks[0];
    for (int i = 1; i < n; ++i)
        if (marks[i] > best) best = marks[i];
    return best;          // best dies when the function ends
}

int main()
{
    int marks[5] = {56, 78, 91, 64, 85};

    std::cout << "Original marks : ";
    for (int m : marks) std::cout << m << ' ';
    std::cout << '\n';

    highest(marks, 5) += 2;          // function call on the left of an assignment operator
    std::cout << "After +2 moderation on highest: ";
    for (int m : marks) std::cout << m << ' ';
    std::cout << '\n';

    const int& r = highestRead(marks, 5);
    // r += 2;   // compile error: assignment of read-only reference
    int copy = highestCopy(marks, 5);
    copy += 2;                       // changes only the copy
    std::cout << "const ref value = " << r << ", copy after +2 = " << copy
              << ", array still has " << marks[2] << '\n';

    // Index version
    int idx = 0;
    for (int i = 1; i < 5; ++i) if (marks[i] > marks[idx]) idx = i;
    marks[idx] += 1;
    std::cout << "Index version : highest at index " << idx << " now " << marks[idx] << '\n';

    // Pointer version
    int* p = &marks[0];
    for (int i = 1; i < 5; ++i) if (marks[i] > *p) p = &marks[i];
    *p += 1;
    std::cout << "Pointer version: highest now " << *p << '\n';

    // vector can grow -> reference may become invalid
    std::vector<int> v = {56, 78, 91};
    int& ref = v[2];
    const int* before = &v[0];
    std::cout << "\nvector capacity before = " << v.capacity() << ", ref -> " << ref << '\n';
    for (int i = 0; i < 20; ++i) v.push_back(i);   // forces reallocation
    const int* after = &v[0];
    std::cout << "buffer moved? " << std::boolalpha << (before != after)
              << ", capacity now = " << v.capacity() << '\n';
    // using 'ref' here would be undefined behaviour (it points into the old freed buffer)
    int idxSafe = 2;                  // index stays valid
    std::cout << "index still valid: v[" << idxSafe << "] = " << v[idxSafe] << '\n';

    // badHighest() is deliberately never called: using its result is undefined behaviour
}
