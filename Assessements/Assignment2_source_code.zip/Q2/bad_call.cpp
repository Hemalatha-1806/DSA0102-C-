#include <iostream>
int& badHighest(int marks[], int n)
{
    int best = marks[0];
    for (int i = 1; i < n; ++i) if (marks[i] > best) best = marks[i];
    return best;
}
int main()
{
    int marks[5] = {56, 78, 91, 64, 85};
    int& r = badHighest(marks, 5);
    std::cout << "value through dangling reference: " << r << '\n';
}
