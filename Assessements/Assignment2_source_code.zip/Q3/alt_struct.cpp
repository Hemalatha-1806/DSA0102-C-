#include <iostream>
#include <type_traits>

// Alternative 1: one struct with optional fields (defaults live in the struct)
struct ChargeRequest {
    double kg;
    bool express = false;
    bool insured = false;
};
double charge(const ChargeRequest& r)
{
    return 50 + 30 * r.kg + (r.express ? 50 : 0) + (r.insured ? 20 : 0);
}

// Alternative 2: function template, unit decided at compile time
template <class W>
double chargeT(W weight, bool express = false, bool insured = false)
{
    double kg = std::is_integral<W>::value ? weight / 1000.0 : double(weight);
    return 50 + 30 * kg + (express ? 50 : 0) + (insured ? 20 : 0);
}

int main()
{
    std::cout << charge({2.0}) << ' ' << charge({2.0, true}) << ' ' << charge({2.0, true, true}) << '\n';
    std::cout << chargeT(500) << ' ' << chargeT(2.5) << ' ' << chargeT(2.0f, true) << '\n';
}
