#include <iostream>

double charge(double weight)                    { return 50 + 30 * weight; }
double charge(double weight, bool express)      { return 50 + 30 * weight + (express ? 50 : 0); }
double charge(double weight, bool express = false, bool insured = false)
{
    return 50 + 30 * weight + (express ? 50 : 0) + (insured ? 20 : 0);
}

int main()
{
    std::cout << charge(2.0) << '\n';        // which one?
    std::cout << charge(2.0, true) << '\n';  // which one?
}
