#include <iostream>

struct Parcel {
    double weightKg;
    bool express;
    bool insured;
};

// default arguments only on ONE function per kind of input -> no ambiguity
double charge(int grams,  bool express = false, bool insured = false);
double charge(double kg,  bool express = false, bool insured = false);
double charge(const Parcel& p);

double charge(double kg, bool express, bool insured)
{
    std::cout << "[double kg version] ";
    return 50 + 30 * kg + (express ? 50 : 0) + (insured ? 20 : 0);
}

double charge(int grams, bool express, bool insured)
{
    std::cout << "[int grams version] ";
    // not calling charge(double...) here so the message stays clear
    double kg = grams / 1000.0;
    return 50 + 30 * kg + (express ? 50 : 0) + (insured ? 20 : 0);
}

double charge(const Parcel& p)
{
    std::cout << "[Parcel version]    ";
    return 50 + 30 * p.weightKg + (p.express ? 50 : 0) + (p.insured ? 20 : 0);
}

int main()
{
    Parcel p{3.0, true, true};

    std::cout << "1. charge(500)          = " << charge(500) << '\n';
    std::cout << "2. charge(2.5)          = " << charge(2.5) << '\n';
    std::cout << "3. charge(2)            = " << charge(2) << '\n';
    std::cout << "4. charge(2.0f)         = " << charge(2.0f) << '\n';
    std::cout << "5. charge(1.5, true)    = " << charge(1.5, true) << '\n';
    std::cout << "6. charge(p)            = " << charge(p) << '\n';
    std::cout << "7. charge(1500,true,true) = " << charge(1500, true, true) << '\n';
}
