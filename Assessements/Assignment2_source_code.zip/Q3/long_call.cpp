#include <iostream>
double charge(int g, bool e = false)    { return g; }
double charge(double kg, bool e = false){ return kg; }
int main() { std::cout << charge(2L) << '\n'; }
